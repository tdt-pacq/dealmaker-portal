import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom';
import { getAuth, setAuth, clearAuth } from './api';
import Dashboard from './pages/Dashboard';
import NewDeal from './pages/NewDeal';
import DealDetail from './pages/DealDetail';

function LoginScreen({ onLogin, error }) {
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');

  const submit = (e) => {
    e.preventDefault();
    onLogin(user, pass);
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: '#1A1A1A'
    }}>
      <div style={{ width: 360, background: 'white', borderRadius: 10, overflow: 'hidden', boxShadow: '0 8px 40px rgba(0,0,0,0.5)' }}>
        <div style={{ background: '#1A1A1A', padding: '28px 32px', textAlign: 'center', borderBottom: '3px solid #C1622F' }}>
          <div style={{ fontFamily: 'Oswald, sans-serif', fontWeight: 700, fontSize: 20, color: 'white', letterSpacing: 1 }}>
            PETERSON ACQUISITIONS
          </div>
          <div style={{ fontFamily: 'Oswald, sans-serif', fontSize: 11, color: '#C1622F', letterSpacing: 2, marginTop: 3 }}>
            THE DEAL TEAM — INTERNAL PLATFORM
          </div>
        </div>
        <form onSubmit={submit} style={{ padding: '28px 32px' }}>
          <div style={{ marginBottom: 16 }}>
            <label>Username</label>
            <input type="text" value={user} onChange={e => setUser(e.target.value)} autoFocus autoComplete="username" />
          </div>
          <div style={{ marginBottom: 20 }}>
            <label>Password</label>
            <input type="password" value={pass} onChange={e => setPass(e.target.value)} autoComplete="current-password" />
          </div>
          {error && <div className="alert alert-error" style={{ marginBottom: 16 }}>{error}</div>}
          <button type="submit" className="btn-primary btn-lg" style={{ width: '100%' }}>
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
}

export default function App() {
  const [authed, setAuthed] = useState(!!getAuth());
  const [loginError, setLoginError] = useState('');

  const handleLogin = async (user, pass) => {
    setAuth(user, pass);
    // Verify credentials
    try {
      const res = await fetch('/api/deals', {
        headers: { Authorization: `Basic ${btoa(`${user}:${pass}`)}` }
      });
      if (res.status === 401) {
        clearAuth();
        setLoginError('Invalid username or password');
      } else {
        setAuthed(true);
        setLoginError('');
      }
    } catch {
      setLoginError('Server unavailable. Please try again.');
      clearAuth();
    }
  };

  const handleLogout = () => {
    clearAuth();
    setAuthed(false);
  };

  if (!authed) {
    return <LoginScreen onLogin={handleLogin} error={loginError} />;
  }

  return (
    <BrowserRouter>
      <div className="app-shell">
        <header className="topbar">
          <NavLink to="/" className="topbar-brand">
            <div>
              <div className="topbar-logo-text">Peterson Acquisitions</div>
              <div className="topbar-logo-sub">The Deal Team</div>
            </div>
          </NavLink>
          <nav className="topbar-nav">
            <NavLink to="/" end className={({ isActive }) => isActive ? 'active' : ''}>
              Dashboard
            </NavLink>
            <NavLink to="/deals/new" className={({ isActive }) => isActive ? 'active' : ''}>
              + New Deal
            </NavLink>
          </nav>
          <div className="topbar-user">
            <button
              onClick={handleLogout}
              style={{ background: 'none', border: 'none', color: '#C1622F', fontSize: 12, fontWeight: 600, cursor: 'pointer', letterSpacing: 0.5 }}
            >
              Sign Out
            </button>
          </div>
        </header>

        <main className="page-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/deals/new" element={<NewDeal />} />
            <Route path="/deals/:id" element={<DealDetail />} />
            <Route path="/deals/:id/edit" element={<NewDeal />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
